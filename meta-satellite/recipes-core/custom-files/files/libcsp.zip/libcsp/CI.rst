Continous Integration
=====================

libcsp uses Travis-CI App for continous integration: https://github.com/marketplace/travis-ci.

libcsp on Travis: https://travis-ci.com/libcsp/libcsp/branches
