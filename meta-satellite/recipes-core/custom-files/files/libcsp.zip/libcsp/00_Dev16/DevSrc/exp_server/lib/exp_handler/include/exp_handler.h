#ifndef exp_handler_H
#define exp_handler_H

#ifdef __cplusplus
extern "C" {
#endif

void exp_handler_init(void);

#ifdef __cplusplus
}
#endif

#endif /* exp_handler_H */