/*
 * Interface: CAN0 @ 500.000
 * EXP-SATELLITE ESAT93
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdbool.h>
#include <time.h>
#include <sys/sysinfo.h>
#include <dirent.h>
#include <sys/stat.h>

#include <csp/csp.h>
#include <csp/arch/csp_thread.h>
#include <csp/drivers/can_socketcan.h>

/* ========== HOST ========== */
#define OBC_ADDRESS            1       // OBC server address

/* ========== EXP-SAT ========== */
#define EXP_ADDRESS            8       
#define CAN_INTERFACE          "can0"
#define CAN_BITRATE            500000

/* ========== CSP Standard Ports ========== */
#define CSP_CMD                0
#define CSP_PING               1
#define CSP_PS                 2
#define CSP_MEM_FREE           3
#define CSP_REBOOT             4
#define CSP_BUF_FREE           5
#define CSP_UPTIME             6

/* ========== BEE-PROJECT Ports ========== */
#define BEE_PARAMS             7 

/* ========== BEE Control Register Addresses ========== */
#define REG_STATUS             0x0000
#define REG_PWR_TEC            0x0011
#define REG_PWR_HTR            0x0012
#define REG_PWR_SLN            0x0013
#define REG_PWR_PZP            0x0014
#define REG_PWR_PHOTO          0x0015
#define REG_PWR_LASER          0x0016

/* ========== File Management Registers ========== */
#define REG_LIST_FOLDERS       0x0080
#define REG_LIST_FILES         0x0081
#define REG_CAT_FILE           0x0082
/* ========== PWM Control Registers ========== */
#define REG_PWM_HEATER         0x0090  // PWM Heater control

/* ========== Data Path ========== */
#define DATA_ROOT_PATH         "/home/root/.a55_src/01_data"
#define MAX_FOLDERS            60
#define MAX_FILES_PER_PART     60
#define CSP_BUFFER_SIZE        256

/* ========== Global Variables ========== */
static csp_iface_t *can_iface = NULL;
static uint32_t boot_time = 0;
static uint32_t request_count = 0;

/* ========== Helper Functions ========== */

/**
 * Get system uptime in seconds
 */
uint32_t get_uptime(void) {
    struct sysinfo info;
    if (sysinfo(&info) == 0) {
        return (uint32_t)info.uptime;
    }
    return 0;
}

/**
 * Get free memory
 */
void get_memory_info(uint32_t *total, uint32_t *free_mem) {
    struct sysinfo info;
    if (sysinfo(&info) == 0) {
        *total = info.totalram * info.mem_unit;
        *free_mem = info.freeram * info.mem_unit;
    } else {
        *total = 0;
        *free_mem = 0;
    }
}

/**
 * Execute external command and capture output
 * Returns 0 on success, -1 on error
 */
int execute_command(const char *cmd, char *output, size_t output_size) {
    FILE *fp;
    char buffer[256];
    
    output[0] = '\0';
    
    fp = popen(cmd, "r");
    if (fp == NULL) {
        snprintf(output, output_size, "ERROR: Failed to execute command");
        return -1;
    }
    
    // Read command output
    size_t total_len = 0;
    while (fgets(buffer, sizeof(buffer), fp) != NULL) {
        size_t len = strlen(buffer);
        if (total_len + len < output_size - 1) {
            strcat(output, buffer);
            total_len += len;
        }
    }
    
    // Remove trailing newline
    if (total_len > 0 && output[total_len - 1] == '\n') {
        output[total_len - 1] = '\0';
    }
    
    int status = pclose(fp);
    return (status == 0) ? 0 : -1;
}

/**
 * Control PWM heater with frequency, duty cycle, and enable/disable
 * Payload format: [freq 4bytes big-endian][duty% 1byte][enable 1byte]
 * Returns: Status message
 */
int control_pwm_heater(uint8_t *payload, size_t payload_len, char *response, size_t resp_size) {
    
    if (payload_len < 6) {
        snprintf(response, resp_size, "ERROR: Invalid payload length (%zu bytes, need 6)", payload_len);
        return strlen(response) + 1;
    }
    
    // Parse frequency (4 bytes, big-endian)
    uint32_t frequency = ((uint32_t)payload[0] << 24) |
                        ((uint32_t)payload[1] << 16) |
                        ((uint32_t)payload[2] << 8) |
                        ((uint32_t)payload[3]);
    
    // Parse duty cycle percentage (1 byte, 0-100)
    uint8_t duty_percent = payload[4];
    
    // Parse enable/disable (1 byte, 0=off, 1=on)
    uint8_t enable = payload[5];
    
    printf("[PWM_HEATER] Frequency: %u Hz\n", frequency);
    printf("[PWM_HEATER] Duty cycle: %u%%\n", duty_percent);
    printf("[PWM_HEATER] Enable: %s\n", enable ? "ON" : "OFF");
    
    // Validate parameters
    if (frequency == 0) {
        snprintf(response, resp_size, "ERROR: Frequency cannot be zero");
        return strlen(response) + 1;
    }
    
    if (duty_percent > 100) {
        snprintf(response, resp_size, "ERROR: Duty cycle must be 0-100%%");
        return strlen(response) + 1;
    }
    
    if (enable > 1) {
        snprintf(response, resp_size, "ERROR: Enable must be 0 or 1");
        return strlen(response) + 1;
    }
    
    // Build command string
    char cmd[512];
    snprintf(cmd, sizeof(cmd), 
             "/usr/bin/python3 /home/root/tools/pwm_control.py -f %u -p %u -c %s",
             frequency, duty_percent, enable ? "on" : "off");
    
    printf("[PWM_HEATER] Executing: %s\n", cmd);
    
    char output[512];
    int ret = execute_command(cmd, output, sizeof(output));
    
    if (ret == 0) {
        printf("[PWM_HEATER] Success: %s\n", output);
        snprintf(response, resp_size, 
                 "OK: PWM Heater %s - %u Hz @ %u%%", 
                 enable ? "ON" : "OFF", frequency, duty_percent);
    } else {
        printf("[PWM_HEATER] Error: %s\n", output);
        snprintf(response, resp_size, "ERROR: %s", output);
    }
    
    return strlen(response) + 1;
}

/**
 * Control TCA6416 GPIO expander
 */
int control_tca6416(uint8_t pin, uint8_t state) {
    char cmd[256];
    char output[512];
    
    snprintf(cmd, sizeof(cmd), "/usr/bin/python3 /home/root/tools/tca6416.py %d %d", pin, state);
    
    printf("[TCA6416] Executing: %s\n", cmd);
    
    int ret = execute_command(cmd, output, sizeof(output));
    
    if (ret == 0) {
        printf("[TCA6416] Success: %s\n", output);
    } else {
        printf("[TCA6416] Error: %s\n", output);
    }
    
    return ret;
}

/**
 * Get system uptime and current epoch in binary format (9 bytes total)
 * [0] = status flag (0 = OK)
 * [1-4] = uptime (uint32_t, little-endian)
 * [5-8] = epoch  (uint32_t, little-endian)
 */
int get_system_status(char *output, size_t output_size) {
    struct sysinfo info;
    time_t now;

    if (output_size < 9) {
        fprintf(stderr, "[STATUS] Buffer too small\n");
        return -1;
    }

    // Lấy uptime
    if (sysinfo(&info) != 0) {
        output[0] = 1; // lỗi
        memset(output + 1, 0, 8);
        return -1;
    }

    // Lấy thời gian hiện tại
    now = time(NULL);
    if (now == (time_t)-1) {
        output[0] = 2; // lỗi
        memset(output + 1, 0, 8);
        return -1;
    }

    // Ghi flag OK
    output[0] = 0;

    uint32_t uptime = (uint32_t)info.uptime;
    uint32_t epoch  = (uint32_t)now;

    // Ghi little-endian
    output[1] = (uptime >> 0) & 0xFF;
    output[2] = (uptime >> 8) & 0xFF;
    output[3] = (uptime >> 16) & 0xFF;
    output[4] = (uptime >> 24) & 0xFF;

    output[5] = (epoch >> 0) & 0xFF;
    output[6] = (epoch >> 8) & 0xFF;
    output[7] = (epoch >> 16) & 0xFF;
    output[8] = (epoch >> 24) & 0xFF;

    printf("[STATUS] OK -> uptime=%u, epoch=%u\n", uptime, epoch);
    return 0;
}

/**
 * Check if string is valid date folder (YYMMDD format)
 */
bool is_valid_date_folder(const char *name) {
    if (strlen(name) != 6) return false;
    
    for (int i = 0; i < 6; i++) {
        if (name[i] < '0' || name[i] > '9') return false;
    }
    
    return true;
}

/**
 * List date folders in data directory
 * Returns: [count 1byte][yy mm dd][yy mm dd]...
 */
int list_date_folders(uint8_t *response, size_t max_size) {
    DIR *dir;
    struct dirent *entry;
    uint8_t count = 0;
    size_t offset = 1; // Reserve first byte for count
    
    printf("[LIST_FOLDERS] Scanning: %s\n", DATA_ROOT_PATH);
    
    dir = opendir(DATA_ROOT_PATH);
    if (dir == NULL) {
        printf("[LIST_FOLDERS] Error: Cannot open directory\n");
        response[0] = 0;
        return 1;
    }
    
    while ((entry = readdir(dir)) != NULL && count < MAX_FOLDERS) {
        if (entry->d_type == DT_DIR && is_valid_date_folder(entry->d_name)) {
            
            if (offset + 3 > max_size) {
                printf("[LIST_FOLDERS] Buffer full, stopping at %d folders\n", count);
                break;
            }
            
            // Parse YYMMDD
            uint8_t yy = (entry->d_name[0] - '0') * 10 + (entry->d_name[1] - '0');
            uint8_t mm = (entry->d_name[2] - '0') * 10 + (entry->d_name[3] - '0');
            uint8_t dd = (entry->d_name[4] - '0') * 10 + (entry->d_name[5] - '0');
            
            response[offset++] = yy;
            response[offset++] = mm;
            response[offset++] = dd;
            
            count++;
            printf("[LIST_FOLDERS] Found: %s -> %02d/%02d/%02d\n", 
                   entry->d_name, yy, mm, dd);
        }
    }
    
    closedir(dir);
    
    response[0] = count;
    
    // Fill remaining buffer with zeros to reach 256 bytes
    while (offset < max_size) {
        response[offset++] = 0;
    }
    
    printf("[LIST_FOLDERS] Total folders: %d, Buffer size: %zu bytes\n", count, offset);
    
    return offset;
}

/**
 * List files in specific folder - returns file count and highest ID
 * Payload: [yy mm dd][resolution 0=High/1=Low]
 * Returns: [file_count 2bytes big-endian][highest_id 4bytes ASCII]
 */
int list_files(uint8_t *payload, size_t payload_len, uint8_t *response, size_t max_size) {
    
    if (payload_len < 4) {
        printf("[LIST_FILES] Error: Invalid payload length\n");
        response[0] = 0;
        response[1] = 0;
        memset(&response[2], '0', 4); // "0000"
        return 6;
    }
    
    uint8_t yy = payload[0];
    uint8_t mm = payload[1];
    uint8_t dd = payload[2];
    uint8_t resolution = payload[3]; // 0=High, 1=Low
    
    printf("[LIST_FILES] Request: %02d/%02d/%02d, Res=%s\n",
           yy, mm, dd, resolution ? "Low" : "High");
    
    // Build path: DATA_ROOT_PATH/YYMMDD/HighResolution or LowResolution
    char folder_path[512];
    snprintf(folder_path, sizeof(folder_path), "%s/%02d%02d%02d/%s",
             DATA_ROOT_PATH, yy, mm, dd,
             resolution ? "LowResolution" : "HighResolution");
    
    printf("[LIST_FILES] Path: %s\n", folder_path);
    
    DIR *dir = opendir(folder_path);
    if (dir == NULL) {
        printf("[LIST_FILES] Error: Cannot open directory\n");
        response[0] = 0;
        response[1] = 0;
        memset(&response[2], '0', 4); // "0000"
        return 6;
    }
    
    // Collect all file IDs (format: 0000_CAM1_1760340119.txt)
    int total_files = 0;
    int highest_id = -1;

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG) {
            if (strlen(entry->d_name) >= 5) {
                bool valid = true;
                for (int i = 0; i < 4; i++) {
                    if (entry->d_name[i] < '0' || entry->d_name[i] > '9') {
                        valid = false;
                        break;
                    }
                }

                if (valid && entry->d_name[4] == '_') {
                    total_files++;
                    int id_num = atoi(entry->d_name);
                    if (id_num > highest_id) {
                        highest_id = id_num;
                    }
                }
            }
        }
    }
    closedir(dir);
    
    printf("[LIST_FILES] Total files found: %d\n", total_files);
    printf("[LIST_FILES] Highest ID: %04d\n", highest_id >= 0 ? highest_id : 0);
    
    // Build response: [file_count 2bytes][highest_id 4bytes ASCII]
    uint16_t count = (uint16_t)total_files;
    response[0] = (count >> 8) & 0xFF;  // High byte
    response[1] = count & 0xFF;          // Low byte
    
    // Highest ID as 4 ASCII characters
    if (highest_id >= 0) {
        snprintf((char *)&response[2], 11, "%04d", highest_id);
    } else {
        memcpy(&response[2], "0000", 4);
    }
    
    printf("[LIST_FILES] Response: Count=%d, Highest ID=%.4s, Bytes: 6\n",
           total_files, (char *)&response[2]);
    
    return 6;  // 2 bytes count + 4 bytes ASCII ID
}

/**
 * Cat file to console and return file size + filename
 * Payload: [yy mm dd][resolution 0=High/1=Low][file_id 4bytes ASCII]
 * Returns: [file_size 4bytes big-endian][filename 20bytes ASCII]
 */
int cat_file(uint8_t *payload, size_t payload_len, uint8_t *response, size_t max_size) {
    
    if (payload_len < 8) {
        const char *err = "ERROR: Invalid payload";
        strncpy((char *)response, err, max_size);
        return strlen(err) + 1;
    }
    
    uint8_t yy = payload[0];
    uint8_t mm = payload[1];
    uint8_t dd = payload[2];
    uint8_t resolution = payload[3]; // 0=High, 1=Low
    
    // Extract file_id as 4 ASCII characters
    char file_id[5];
    memcpy(file_id, &payload[4], 4);
    file_id[4] = '\0';
    
    printf("[CAT_FILE] Date: %02d/%02d/%02d, Res=%s, FileID=%s\n",
           yy, mm, dd, resolution ? "Low" : "High", file_id);
    
    // Build folder path
    char folder_path[512];
    snprintf(folder_path, sizeof(folder_path), "%s/%02d%02d%02d/%s",
             DATA_ROOT_PATH, yy, mm, dd,
             resolution ? "LowResolution" : "HighResolution");
    
    printf("[CAT_FILE] Folder path: %s\n", folder_path);
    
    DIR *dir = opendir(folder_path);
    if (dir == NULL) {
        const char *err = "ERROR: Cannot open folder";
        strncpy((char *)response, err, max_size);
        return strlen(err) + 1;
    }
    
    bool found = false;
    char file_path[768];
    char found_filename[256];
    
    // Search for file with matching file_id prefix
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_REG) {
            // Check if filename starts with file_id (format: 0000_CAM1_1760340119.txt)
            if (strncmp(entry->d_name, file_id, 4) == 0 && 
                entry->d_name[4] == '_') {
                snprintf(file_path, sizeof(file_path), "%s/%s", 
                        folder_path, entry->d_name);
                strncpy(found_filename, entry->d_name, sizeof(found_filename) - 1);
                found_filename[sizeof(found_filename) - 1] = '\0';
                found = true;
                break;
            }
        }
    }
    closedir(dir);
    
    if (!found) {
        char err[64];
        snprintf(err, sizeof(err), "ERROR: File not found (ID=%s)", file_id);
        strncpy((char *)response, err, max_size);
        return strlen(err) + 1;
    }
    
    printf("[CAT_FILE] Found: %s\n", file_path);
    printf("[CAT_FILE] Filename: %s\n", found_filename);
    
    // Write to exprom-file
    char cmd[1024];
    snprintf(cmd, sizeof(cmd),
              "cat \"%s\" > /sys/bus/i2c/devices/4-1064/exprom-file", file_path);
    int ret = system(cmd);
    if (ret != 0) {
        printf("[CAT_FILE] Warning: system() cat to exprom-file failed.\n");
    } else {
        printf("[CAT_FILE] File content written to exprom-file via system().\n");
    }

    // Get file size
    struct stat st;
    if (stat(file_path, &st) != 0) {
        const char *err = "ERROR: Cannot stat file";
        strncpy((char *)response, err, max_size);
        return strlen(err) + 1;
    }
    
    uint32_t file_size = (uint32_t)st.st_size;
    
    printf("[CAT_FILE] File size: %u bytes\n", file_size);
    printf("[CAT_FILE] === Displaying file content ===\n");
    
    // Cat file to console (server side only)
    FILE *fp = fopen(file_path, "r");
    if (fp != NULL) {
        char line[256];
        while (fgets(line, sizeof(line), fp) != NULL) {
            printf("%s", line);
        }
        fclose(fp);
        printf("\n[CAT_FILE] === End of file ===\n");
    } else {
        printf("[CAT_FILE] Warning: Could not open file for display\n");
    }
    
    // Prepare filename (20 bytes, extract only filename without extension)
    char clean_filename[21];
    memset(clean_filename, 0, sizeof(clean_filename));
    
    // Remove extension from filename
    char *dot_pos = strrchr(found_filename, '.');
    size_t name_len = dot_pos ? (size_t)(dot_pos - found_filename) : strlen(found_filename);
    if (name_len > 20) name_len = 20;
    
    strncpy(clean_filename, found_filename, name_len);
    clean_filename[20] = '\0';
    
    // Build response: [4 bytes size][20 bytes filename]
    size_t offset = 0;
    
    // File size (4 bytes, big-endian)
    response[offset++] = (file_size >> 24) & 0xFF;
    response[offset++] = (file_size >> 16) & 0xFF;
    response[offset++] = (file_size >> 8) & 0xFF;
    response[offset++] = file_size & 0xFF;
    
    // Filename (20 bytes ASCII)
    memcpy(&response[offset], clean_filename, 20);
    offset += 20;
    
    printf("[CAT_FILE] Returning - Size: %u bytes, Filename: %.20s\n", 
           file_size, clean_filename);
    
    return 24;  // Return 24 bytes (4 + 20)
}


/**
 * Parse and execute BEE control command
 */
int parse_bee_command(uint8_t *payload, uint16_t length, char *response, size_t resp_size) {
    
    if (length < 3) {
        snprintf(response, resp_size, "ERROR: Invalid payload length (%d bytes, need at least 3)", length);
        return -1;
    }
    
    // Parse register address (big-endian)
    uint16_t addr_reg = (payload[0] << 8) | payload[1];
    
    printf("[BEE_PARAMS] Parsed command - Addr: 0x%04X\n", addr_reg);
    
    int ret = 0;
    
    switch (addr_reg) {
    case REG_STATUS:
            printf("[BEE_PARAMS] Getting system status...\n");
            ret = get_system_status(response, resp_size);
            if (ret == 0) {
                return 9;
            } else {
                snprintf(response, resp_size, "ERROR: get_system_status failed");
                return strlen(response) + 1;
            }
            break;
                    
        case REG_PWR_TEC: {
            uint8_t data = payload[2];
            printf("[BEE_PARAMS] TEC power control: %s\n", data ? "ON" : "OFF");
            ret = control_tca6416(4, data ? 1 : 0);
            snprintf(response, resp_size, "OK: TEC power %s", data ? "ON" : "OFF");
            break;
        }
            
        case REG_PWR_HTR: {
            uint8_t data = payload[2];
            printf("[BEE_PARAMS] Heater power control: %s\n", data ? "ON" : "OFF");
            ret = control_tca6416(1, data ? 1 : 0);
            snprintf(response, resp_size, "OK: Heater power %s", data ? "ON" : "OFF");
            break;
        }
            
        case REG_PWR_SLN: {
            uint8_t data = payload[2];
            printf("[BEE_PARAMS] Solenoid valve control: %s\n", data ? "ON" : "OFF");
            ret = control_tca6416(2, data ? 1 : 0);
            snprintf(response, resp_size, "OK: Solenoid valve %s", data ? "ON" : "OFF");
            break;
        }
            
        case REG_PWR_PZP: {
            uint8_t data = payload[2];
            printf("[BEE_PARAMS] Piezoelectric pump control: %s\n", data ? "ON" : "OFF");
            ret = control_tca6416(3, data ? 1 : 0);
            snprintf(response, resp_size, "OK: Piezo pump %s", data ? "ON" : "OFF");
            break;
        }
            
        case REG_PWR_PHOTO: {
            uint8_t data = payload[2];
            printf("[BEE_PARAMS] Photo power control: %s\n", data ? "ON" : "OFF");
            ret = control_tca6416(6, data ? 1 : 0);
            snprintf(response, resp_size, "OK: Photo power %s", data ? "ON" : "OFF");
            break;
        }
            
        case REG_PWR_LASER: {
            uint8_t data = payload[2];
            printf("[BEE_PARAMS] Laser power control: %s\n", data ? "ON" : "OFF");
            ret = control_tca6416(7, data ? 1 : 0);
            snprintf(response, resp_size, "OK: Laser power %s", data ? "ON" : "OFF");
            break;
        }
            
        case REG_LIST_FOLDERS: {
            printf("[BEE_PARAMS] Listing date folders...\n");
            int bytes = list_date_folders((uint8_t *)response, resp_size);
            return bytes; // Return binary data length
        }
            
        case REG_LIST_FILES: {
            printf("[BEE_PARAMS] Listing files...\n");
            int bytes = list_files(&payload[2], length - 2, (uint8_t *)response, resp_size);
            return bytes; // Return binary data length
        }
            
        case REG_CAT_FILE: {
            printf("[BEE_PARAMS] Reading file content...\n");
            int bytes = cat_file(&payload[2], length - 2,(uint8_t *)response, resp_size);
            return bytes; // Return text data length
        }
        case REG_PWM_HEATER: {
            printf("[BEE_PARAMS] PWM Heater control...\n");
            int bytes = control_pwm_heater(&payload[2], length - 2, response, resp_size);
            return bytes;
        }
            
        default:
            printf("[BEE_PARAMS] Unknown register: 0x%04X\n", addr_reg);
            snprintf(response, resp_size, "ERROR: Unknown register 0x%04X", addr_reg);
            ret = -1;
            break;
    }
    
    if (ret != 0 && strncmp(response, "ERROR:", 6) != 0) {
        char temp[512];
        snprintf(temp, sizeof(temp), "ERROR: Command failed for register 0x%04X", addr_reg);
        strncpy(response, temp, resp_size - 1);
        response[resp_size - 1] = '\0';
    }
    
    return strlen(response) + 1;
}

/* ========== Port Handlers ========== */

void handle_cmd(csp_conn_t *conn, csp_packet_t *packet) {
    printf("[PORT 0 - CMD] Received command request from node %u\n", csp_conn_src(conn));
    
    const char *response = "CMD_OK";
    snprintf((char *)packet->data, csp_buffer_data_size(), "%s", response);
    packet->length = strlen(response) + 1;
    
    if (!csp_send(conn, packet, 1000)) {
        csp_log_error("[CMD] Failed to send response");
        csp_buffer_free(packet);
    } else {
        printf("[CMD] Sent response: %s\n", response);
    }
}

void handle_ping(csp_conn_t *conn, csp_packet_t *packet) {
    printf("[PORT 1 - PING] Received PING request from node %u\n", csp_conn_src(conn));
    
    snprintf((char *)packet->data, csp_buffer_data_size(), "200 OK");
    packet->length = strlen((char *)packet->data) + 1;
    
    if (!csp_send(conn, packet, 1000)) {
        csp_log_error("[PING] Failed to send response");
        csp_buffer_free(packet);
    } else {
        printf("[PING] Sent response: %s\n", (char *)packet->data);
    }
}

void handle_ps(csp_conn_t *conn, csp_packet_t *packet) {
    printf("[PORT 2 - PS] Received PS request from node %u\n", csp_conn_src(conn));
    
    const char *response = "PS_INFO";
    snprintf((char *)packet->data, csp_buffer_data_size(), 
             "%s: PID=1234 CPU=5%% MEM=10MB", response);
    packet->length = strlen((char *)packet->data) + 1;
    
    if (!csp_send(conn, packet, 1000)) {
        csp_log_error("[PS] Failed to send response");
        csp_buffer_free(packet);
    } else {
        printf("[PS] Sent response: %s\n", (char *)packet->data);
    }
}

void handle_memfree(csp_conn_t *conn, csp_packet_t *packet) {
    printf("[PORT 3 - MEMFREE] Received MEMFREE request from node %u\n", csp_conn_src(conn));
    
    uint32_t total, free_mem;
    get_memory_info(&total, &free_mem);
    
    snprintf((char *)packet->data, csp_buffer_data_size(), 
             "MEMFREE: Total=%u Free=%u", total, free_mem);
    packet->length = strlen((char *)packet->data) + 1;
    
    if (!csp_send(conn, packet, 1000)) {
        csp_log_error("[MEMFREE] Failed to send response");
        csp_buffer_free(packet);
    } else {
        printf("[MEMFREE] Sent response: %s\n", (char *)packet->data);
    }
}

void handle_reboot(csp_conn_t *conn, csp_packet_t *packet) {
    printf("[PORT 4 - REBOOT] Received REBOOT request from node %u\n", csp_conn_src(conn));
    
    const char *response = "REBOOT_ACK";
    snprintf((char *)packet->data, csp_buffer_data_size(), "%s", response);
    packet->length = strlen(response) + 1;
    
    if (!csp_send(conn, packet, 1000)) {
        csp_log_error("[REBOOT] Failed to send response");
        csp_buffer_free(packet);
    } else {
        printf("[REBOOT] Sent response: %s\n", response);
    }
}

void handle_buffree(csp_conn_t *conn, csp_packet_t *packet) {
    printf("[PORT 5 - BUFFREE] Received BUFFREE request from node %u\n", csp_conn_src(conn));
    
    uint32_t free_buffers = csp_buffer_remaining();
    
    snprintf((char *)packet->data, csp_buffer_data_size(), 
             "BUFFREE: %u", free_buffers);
    packet->length = strlen((char *)packet->data) + 1;
    
    if (!csp_send(conn, packet, 1000)) {
        csp_log_error("[BUFFREE] Failed to send response");
        csp_buffer_free(packet);
    } else {
        printf("[BUFFREE] Sent response: %s\n", (char *)packet->data);
    }
}

void handle_uptime(csp_conn_t *conn, csp_packet_t *packet) {
    printf("[PORT 6 - UPTIME] Received UPTIME request from node %u\n", csp_conn_src(conn));
    
    uint32_t uptime = get_uptime();
    uint32_t days = uptime / 86400;
    uint32_t hours = (uptime % 86400) / 3600;
    uint32_t minutes = (uptime % 3600) / 60;
    
    snprintf((char *)packet->data, csp_buffer_data_size(), 
             "UPTIME: %ud %uh %um (%u seconds)", days, hours, minutes, uptime);
    packet->length = strlen((char *)packet->data) + 1;
    
    if (!csp_send(conn, packet, 1000)) {
        csp_log_error("[UPTIME] Failed to send response");
        csp_buffer_free(packet);
    } else {
        printf("[UPTIME] Sent response: %s\n", (char *)packet->data);
    }
}

void handle_bee_params(csp_conn_t *conn, csp_packet_t *packet) {
    printf("[PORT 7 - BEE_PARAMS] Received request from node %u\n", csp_conn_src(conn));
    printf("[BEE_PARAMS] Payload length: %u bytes\n", packet->length);
    
    char response[CSP_BUFFER_SIZE];
    
    if (packet->length > 0) {
        printf("[BEE_PARAMS] Payload (hex): ");
        for (int i = 0; i < packet->length; i++) {
            printf("%02X ", packet->data[i]);
        }
        printf("\n");
        
        int resp_len = parse_bee_command(packet->data, packet->length, response, sizeof(response));
        
        if (resp_len > 0) {
            memcpy(packet->data, response, resp_len);
            packet->length = resp_len;
            printf("[BEE_PARAMS] Response length: %d bytes\n", resp_len);
        } else {
            const char *err = "ERROR: Command failed";
            strcpy((char *)packet->data, err);
            packet->length = strlen(err) + 1;
        }
    } else {
        printf("[BEE_PARAMS] No payload, returning general info\n");
        snprintf((char *)packet->data, csp_buffer_data_size(),
                 "BEE_PARAMS Ready - Packets=%u Uptime=%us",
                 request_count, get_uptime());
        packet->length = strlen((char *)packet->data) + 1;
    }
    
    if (!csp_send(conn, packet, 1000)) {
        csp_log_error("[BEE_PARAMS] Failed to send response");
        csp_buffer_free(packet);
    } else {
        printf("[BEE_PARAMS] Sent response (%u bytes)\n", packet->length);
    }
}

/* ========== Server Task ========== */
CSP_DEFINE_TASK(task_server) {
    
    csp_log_info("Server task started on address %u", EXP_ADDRESS);
    
    csp_socket_t *sock = csp_socket(CSP_SO_NONE);
    if (sock == NULL) {
        csp_log_error("Failed to create socket");
        return CSP_TASK_RETURN;
    }
    
    csp_bind(sock, CSP_ANY);
    csp_listen(sock, 10);
    
    printf("\n");
    printf("=======================================\n");
    printf("  Server listening on all ports\n");
    printf("  Ready to accept connections...\n");
    printf("=======================================\n\n");
    
    while (1) {
        csp_conn_t *conn = csp_accept(sock, 10000);
        if (conn == NULL) {
            continue;
        }
        
        printf("\n[CONNECTION] New connection from node %u\n", csp_conn_src(conn));
        
        csp_packet_t *packet;
        while ((packet = csp_read(conn, 100)) != NULL) {
            
            uint8_t port = csp_conn_dport(conn);
            request_count++;
            
            printf("[PACKET] Received on port %u, length %u bytes\n", port, packet->length);
            
            switch (port) {
                case CSP_CMD:
                    handle_cmd(conn, packet);
                    break;
                case CSP_PING:
                    handle_ping(conn, packet);
                    break;
                case CSP_REBOOT:
                    handle_reboot(conn, packet);
                    break;
                case CSP_BUF_FREE:
                    csp_service_handler(conn, packet);
                    break;
                    
                case CSP_PS:
                    handle_ps(conn, packet);
                    break;
                    
                case CSP_MEM_FREE:
                    handle_memfree(conn, packet);
                    break;
                    
                case CSP_UPTIME:
                    handle_uptime(conn, packet);
                    break;
                    
                case BEE_PARAMS:
                    handle_bee_params(conn, packet);
                    break;
                    
                default:
                    printf("[WARNING] Unknown port %u, using default handler\n", port);
                    csp_service_handler(conn, packet);
                    break;
            }
        }
        
        csp_close(conn);
        printf("[CONNECTION] Connection closed\n");
    }
    
    return CSP_TASK_RETURN;
}

/* ========== Statistics Task ========== */
CSP_DEFINE_TASK(task_stats) {
    
    while (1) {
        csp_sleep_ms(10000);
        
        printf("\n--- Statistics ---\n");
        printf("Total requests handled: %u\n", request_count);
        printf("Free buffers: %u\n", csp_buffer_remaining());
        printf("Uptime: %u seconds\n", get_uptime());
        printf("------------------\n\n");
    }
    
    return CSP_TASK_RETURN;
}

/* ========== Main Function ========== */
int main(int argc, char *argv[]) {
    
    int error;
    uint8_t my_address = EXP_ADDRESS;
    csp_debug_level_t debug_level = CSP_INFO;
    bool show_stats = false;
    
    int opt;
    while ((opt = getopt(argc, argv, "a:d:sh")) != -1) {
        switch (opt) {
            case 'a':
                my_address = atoi(optarg);
                break;
            case 'd':
                debug_level = atoi(optarg);
                break;
            case 's':
                show_stats = true;
                break;
            case 'h':
            default:
                printf("BEE Project - CSP Server\n");
                printf("Usage: %s [options]\n", argv[0]);
                printf("Options:\n");
                printf("  -a <address>     My CSP address (default: %d)\n", EXP_ADDRESS);
                printf("  -d <level>       Debug level 0-6 (default: 4=INFO)\n");
                printf("  -s               Show periodic statistics\n");
                printf("  -h               Show this help\n");
                printf("\nAvailable Ports:\n");
                printf("  Port 0: CSP_CMD\n");
                printf("  Port 1: CSP_PING\n");
                printf("  Port 2: CSP_PS\n");
                printf("  Port 3: CSP_MEM_FREE\n");
                printf("  Port 4: CSP_REBOOT\n");
                printf("  Port 5: CSP_BUF_FREE\n");
                printf("  Port 6: CSP_UPTIME\n");
                printf("  Port 7: BEE_PARAMS (custom control)\n");
                printf("\nBEE_PARAMS Control Registers:\n");
                printf("  0x0000: System status\n");
                printf("  0x0011: TEC power control\n");
                printf("  0x0012: Heater power control\n");
                printf("  0x0013: Solenoid valve control\n");
                printf("  0x0014: Piezoelectric pump control\n");
                printf("  0x0015: Photo power control\n");
                printf("  0x0016: Laser power control\n");
                printf("  0x0080: List date folders\n");
                printf("  0x0081: List files in folder\n");
                printf("  0x0082: Cat file content\n");
                printf("\nExample:\n");
                printf("  %s -a 3 -d 5 -s\n", argv[0]);
                printf("\nSetup CAN first:\n");
                printf("  sudo ip link set can0 type can bitrate 500000\n");
                printf("  sudo ip link set can0 up\n");
                exit(opt == 'h' ? 0 : 1);
        }
    }
    
    for (csp_debug_level_t i = 0; i <= CSP_LOCK; i++) {
        csp_debug_set_level(i, (i <= debug_level) ? true : false);
    }
    
    boot_time = (uint32_t)time(NULL);
    
    printf("\n");
    printf("=======================================\n");
    printf("  BEE Project - CSP Server\n");
    printf("=======================================\n");
    printf("Node Address: %u\n", my_address);
    printf("CAN Interface: %s @ %d bps\n", CAN_INTERFACE, CAN_BITRATE);
    printf("Debug Level: %d\n", debug_level);
    printf("Data Path: %s\n", DATA_ROOT_PATH);
    printf("=======================================\n\n");
    
    csp_log_info("Initializing CSP...");
    csp_conf_t csp_conf;
    csp_conf_get_defaults(&csp_conf);
    csp_conf.address = my_address;
    
    error = csp_init(&csp_conf);
    if (error != CSP_ERR_NONE) {
        csp_log_error("csp_init() failed, error: %d", error);
        return 1;
    }
    
    csp_log_info("Starting router task...");
    csp_route_start_task(500, 0);
    
    csp_log_info("Adding CAN interface: %s", CAN_INTERFACE);
    error = csp_can_socketcan_open_and_add_interface(
        CAN_INTERFACE,
        CSP_IF_CAN_DEFAULT_NAME,
        0,
        false,
        &can_iface
    );
    
    if (error != CSP_ERR_NONE) {
        csp_log_error("Failed to add CAN interface [%s], error: %d", CAN_INTERFACE, error);
        printf("\n");
        printf("ERROR: Cannot initialize CAN interface!\n");
        printf("Please setup CAN first:\n");
        printf("  sudo ip link set can0 type can bitrate 500000\n");
        printf("  sudo ip link set can0 up\n");
        printf("  ip link show can0\n");
        return 1;
    }
    
    csp_rtable_set(CSP_DEFAULT_ROUTE, 0, can_iface, CSP_NO_VIA_ADDRESS);
    
    printf("\nConnection table:\n");
    csp_conn_print_table();
    printf("\nInterfaces:\n");
    csp_route_print_interfaces();
    printf("\nRoute table:\n");
    csp_route_print_table();
    printf("\n");
    
    csp_log_info("CSP initialized successfully!");
    
    csp_thread_handle_t server_handle;
    csp_thread_create(task_server, "SERVER", 2000, NULL, 0, &server_handle);
    
    if (show_stats) {
        csp_thread_handle_t stats_handle;
        csp_thread_create(task_stats, "STATS", 1000, NULL, 0, &stats_handle);
    }
    
    printf("\nServer is running. Press Ctrl+C to stop.\n\n");
    
    while (1) {
        csp_sleep_ms(1000);
    }
    
    return 0;
}
