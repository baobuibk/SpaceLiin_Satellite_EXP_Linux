#!/usr/bin/python3
import sys
import time
import struct
from datetime import datetime
import libcsp_py3 as libcsp

# ==============================
#  CONFIGURATION
# ==============================
OBC_ADDRESS = 1
EXP_ADDRESS = 8
CAN_INTERFACE = "can1" 
TIMEOUT = 1000          

# ==============================
#  MENU COMMANDS
# ==============================
PORTS = {
    0: "CSP_CMD",
    1: "CSP_PING",
    2: "CSP_PS",
    3: "CSP_MEM_FREE",
    4: "CSP_REBOOT",
    5: "CSP_BUF_FREE",
    6: "CSP_UPTIME",
    7: "BEE_PARAMS"
}

# BEE Control Registers
BEE_REGISTERS = {
    0x0000: {"name": "System Status", "type": "read"},
    0x0011: {"name": "TEC Power", "type": "control"},
    0x0012: {"name": "Heater Power", "type": "control"},
    0x0013: {"name": "Solenoid Valve", "type": "control"},
    0x0014: {"name": "Piezo Pump", "type": "control"},
    0x0015: {"name": "Photo Power", "type": "control"},
    0x0016: {"name": "Laser Power", "type": "control"},
    0x0080: {"name": "List Folders", "type": "file"},
    0x0081: {"name": "List Files", "type": "file"},
    0x0082: {"name": "Cat File", "type": "file"},
    0x0090: {"name": "PWM Heater Control", "type": "pwm"}
}

def send_request(port, payload=None):
    """Send CSP request and receive response"""
    if payload is None:
        payload = b"REQ"

    print(f"\n[INFO] Sending request to node {EXP_ADDRESS} port {port} ({PORTS.get(port, 'UNKNOWN')})")
    
    if port == 7 and len(payload) >= 3:
        print(f"[PAYLOAD] Hex: {payload.hex().upper()}")
        reg_addr = (payload[0] << 8) | payload[1]
        print(f"[PAYLOAD] Register: 0x{reg_addr:04X}")

    outbuf = bytearray(payload)
    inbuf = bytearray(256)

    try:
        result = libcsp.transaction(
            libcsp.CSP_PRIO_NORM,
            EXP_ADDRESS,
            port,
            TIMEOUT,
            outbuf,
            inbuf
        )
        print(f"[DEBUG] Transaction result: {result}")
        
        if result:
            return inbuf
        else:
            print("[ERROR] Transaction failed or timeout.\n")
            return None
    except Exception as e:
        print(f"[EXCEPTION] {e}\n")
        return None


def create_bee_payload(register_addr, data_bytes=b''):
    """
    Create BEE_PARAMS payload
    Format: [uint16_t addr_reg (big-endian)][data bytes...]
    """
    payload = bytearray()
    payload.append((register_addr >> 8) & 0xFF)  # High byte
    payload.append(register_addr & 0xFF)          # Low byte
    payload.extend(data_bytes)
    return bytes(payload)


def parse_folder_list(data):
    """
    Parse folder list response
    Format: [count 1byte][yy mm dd][yy mm dd]...
    """
    if len(data) < 1:
        return []
    
    count = data[0]
    folders = []
    offset = 1
    
    for i in range(count):
        if offset + 3 > len(data):
            break
        yy = data[offset]
        mm = data[offset + 1]
        dd = data[offset + 2]
        folders.append((yy, mm, dd))
        offset += 3
    
    return folders

def parse_file_list(data):
    """
    Parse file list response
    Format: [file_count 2bytes big-endian][highest_id 4bytes ASCII]
    """
    if len(data) < 6:
        return None, None
    
    # File count (2 bytes big-endian)
    file_count = (data[0] << 8) | data[1]
    
    # Highest ID (4 bytes ASCII)
    highest_id = data[2:6].decode('ascii', errors='ignore')
    
    return file_count, highest_id

def pwm_heater_menu():
    """PWM Heater control menu with frequency and duty cycle"""
    print("\n" + "="*50)
    print("  PWM Heater Control (0x0090)")
    print("="*50)
    
    # Get frequency
    print("\n[FREQUENCY]")
    print("Common values:")
    print("  1000 Hz  - Standard PWM")
    print("  2000 Hz  - Fast PWM")
    print("  500 Hz   - Slow PWM")
    
    freq_input = input("\nEnter frequency (Hz): ").strip()
    try:
        frequency = int(freq_input)
        if frequency <= 0 or frequency > 100000:
            print("[ERROR] Frequency must be between 1 and 100000 Hz")
            return
    except ValueError:
        print("[ERROR] Invalid frequency value")
        return
    
    # Get duty cycle
    print("\n[DUTY CYCLE]")
    print("Percentage (0-100):")
    print("  0%   - Always OFF")
    print("  25%  - Low power")
    print("  50%  - Medium power")
    print("  75%  - High power")
    print("  100% - Always ON")
    
    duty_input = input("\nEnter duty cycle (%): ").strip()
    try:
        duty_percent = int(duty_input)
        if duty_percent < 0 or duty_percent > 100:
            print("[ERROR] Duty cycle must be between 0 and 100")
            return
    except ValueError:
        print("[ERROR] Invalid duty cycle value")
        return
    
    # Get enable/disable
    print("\n[CONTROL]")
    action = input("Turn PWM ON (1) or OFF (0)? ").strip()
    
    if action not in ['0', '1']:
        print("[ERROR] Invalid input. Use 0 or 1.")
        return
    
    enable = int(action)
    
    # Build payload: [freq 4bytes big-endian][duty% 1byte][enable 1byte]
    payload_data = bytearray()
    payload_data.append((frequency >> 24) & 0xFF)  # Freq byte 3 (MSB)
    payload_data.append((frequency >> 16) & 0xFF)  # Freq byte 2
    payload_data.append((frequency >> 8) & 0xFF)   # Freq byte 1
    payload_data.append(frequency & 0xFF)          # Freq byte 0 (LSB)
    payload_data.append(duty_percent)              # Duty cycle %
    payload_data.append(enable)                    # Enable flag
    
    payload = create_bee_payload(0x0090, bytes(payload_data))
    
    print("\n" + "="*50)
    print("  PWM CONFIGURATION")
    print("="*50)
    print(f"Frequency: {frequency} Hz")
    print(f"Duty Cycle: {duty_percent}%")
    print(f"Action: {'ENABLE' if enable else 'DISABLE'}")
    print(f"Payload (hex): {payload.hex().upper()}")
    print("="*50)
    
    confirm = input("\nSend command? (y/n): ").strip().lower()
    if confirm != 'y':
        print("[CANCELLED] Command not sent.")
        return
    
    print(f"\n[ACTION] Configuring PWM Heater...")
    inbuf = send_request(7, payload)
    
    if inbuf:
        reply_str = inbuf.decode(errors="ignore").strip("\x00")
        print(f"\n[REPLY] {reply_str}\n")
        
        if reply_str.startswith("OK"):
            print("[SUCCESS] PWM Heater configured successfully!")
        else:
            print("[WARNING] Command may have failed. Check server logs.")
    else:
        print("[ERROR] No response from server.")

def list_folders_menu():
    """List all date folders"""
    print("\n" + "="*50)
    print("  List Date Folders")
    print("="*50)
    
    payload = create_bee_payload(0x0080, b'\x00')
    inbuf = send_request(7, payload)
    
    if inbuf:
        folders = parse_folder_list(inbuf)
        
        if folders:
            print(f"\n[FOLDERS] Found {len(folders)} folders:\n")
            for idx, (yy, mm, dd) in enumerate(folders, 1):
                date_str = f"{dd:02d}/{mm:02d}/20{yy:02d}"
                print(f"  {idx:2d}. {date_str}")
            return folders
        else:
            print("[INFO] No folders found.")
            return []
    else:
        print("[ERROR] Failed to retrieve folder list.")
        return []

def list_files_menu():
    """List files in a specific folder - returns file count and highest ID"""
    print("\n" + "="*50)
    print("  List Files in Folder")
    print("="*50)
    
    # First, get folder list
    folders = list_folders_menu()
    if not folders:
        return
    
    # Select folder
    try:
        choice = int(input("\nSelect folder number: ").strip())
        if choice < 1 or choice > len(folders):
            print("[ERROR] Invalid folder number.")
            return
        
        yy, mm, dd = folders[choice - 1]
        print(f"\n[SELECTED] {dd:02d}/{mm:02d}/20{yy:02d}")
        
    except ValueError:
        print("[ERROR] Invalid input.")
        return
    
    # Select resolution
    print("\nResolution:")
    print("  0: High Resolution")
    print("  1: Low Resolution")
    res = input("Select resolution (0/1): ").strip()
    if res not in ['0', '1']:
        print("[ERROR] Invalid resolution.")
        return
    resolution = int(res)
    
    # Build payload: [yy mm dd][resolution]
    data = bytearray([yy, mm, dd, resolution])
    payload = create_bee_payload(0x0081, bytes(data))
    
    print(f"\n[INFO] Requesting file list...")
    inbuf = send_request(7, payload)
    
    if inbuf:
        file_count, highest_id = parse_file_list(inbuf)
        
        if file_count is not None:
            print("\n" + "="*50)
            print("  FILE LIST SUMMARY")
            print("="*50)
            print(f"Total Files: {file_count}")
            print(f"Highest ID: {highest_id} (newest file)")
            print(f"ID Range: 0000 - {highest_id}")
            print("="*50)
            
            if file_count > 0:
                print(f"\n[INFO] Files in this folder: {file_count}")
                print(f"[INFO] File IDs range from 0000 to {highest_id}")
                print(f"[INFO] Use 'Cat File' menu to view specific file by ID")
            
            return (yy, mm, dd), resolution, file_count, highest_id
        else:
            print("[ERROR] Failed to parse file list.")
            return None
    else:
        print("[ERROR] Failed to retrieve file list.")
        return None

def cat_file_menu():
    """
    Read file and display file size + filename
    Response format: [4 bytes size][20 bytes filename ASCII]
    """
    print("\n" + "="*50)
    print("  Cat File - Display File Info")
    print("="*50)
    print("\n[NOTE] File content will be displayed on the SERVER console.")
    print("[NOTE] Client will receive file size and filename.\n")
    
    # Get file list first
    result = list_files_menu()
    if not result:
        return
    
    (yy, mm, dd), resolution, file_count, highest_id = result
    
    if file_count == 0:
        print("[INFO] No files to display.")
        return
    
    # Manual input file ID
    print(f"\n[INFO] Enter file ID (0000 - {highest_id})")
    file_id = input("File ID: ").strip()
    
    # Validate file ID
    if len(file_id) != 4 or not file_id.isdigit():
        print("[ERROR] Invalid file ID. Must be 4 digits (e.g., 0000, 0001, 0015)")
        return
    
    print(f"\n[SELECTED] File ID: {file_id}")
    
    # Build payload: [yy mm dd][resolution][file_id 4 bytes ASCII]
    data = bytearray([yy, mm, dd, resolution])
    data.extend(file_id.encode('ascii'))
    
    payload = create_bee_payload(0x0082, bytes(data))
    
    print("\n[INFO] Requesting file cat (content will show on server)...")
    inbuf = send_request(7, payload)
    
    if inbuf:
        # Check if response is error message
        response_str = inbuf.decode(errors='ignore').strip('\x00')
        
        if response_str.startswith('ERROR'):
            print(f"\n[ERROR] {response_str}")
        else:
            # Response format: [4 bytes size][20 bytes filename]
            if len(inbuf) >= 24:
                # Parse file size (4 bytes, big-endian)
                file_size = (inbuf[0] << 24) | (inbuf[1] << 16) | \
                           (inbuf[2] << 8) | inbuf[3]
                
                # Parse filename (20 bytes ASCII)
                filename = inbuf[4:24].decode('ascii', errors='ignore').rstrip('\x00')
                
                print("\n" + "="*50)
                print("  FILE INFORMATION")
                print("="*50)
                print(f"Date: {dd:02d}/{mm:02d}/20{yy:02d}")
                print(f"File ID: {file_id}")
                print(f"Filename: {filename}")
                print(f"File Size: {file_size} bytes ({file_size / 1024:.2f} KB)")
                print(f"Resolution: {'High' if resolution == 0 else 'Low'}")
                print("="*50)
                print("\n[INFO] File content has been displayed on the server console.")
                print("[INFO] Check the server terminal to see the file content.")
            else:
                print(f"\n[RESPONSE] {response_str}")
    else:
        print("[ERROR] Failed to read file.")


def file_management_menu():
    """File management submenu"""
    while True:
        print("\n" + "="*50)
        print("  File Management Menu")
        print("="*50)
        print("\n[Operations]")
        print("  1: List Date Folders")
        print("  2: List Files in Folder (Count + Highest ID)")
        print("  3: Cat File Content (by File ID)")
        print("  B: Back to main menu")
        
        choice = input("\nSelect option: ").strip().upper()
        
        if choice == 'B':
            return
        elif choice == '1':
            list_folders_menu()
        elif choice == '2':
            list_files_menu()
        elif choice == '3':
            cat_file_menu()
        else:
            print("[ERROR] Invalid choice.")


def bee_params_menu():
    """Interactive menu for BEE_PARAMS control"""
    
    while True:
        print("\n" + "="*50)
        print("  BEE_PARAMS Control Menu (Port 7)")
        print("="*50)
        
        print("\n[Read Operations]")
        print("  0: Get System Status (0x0000)")
        
        print("\n[Power Control]")
        print("  1: TEC Power Control (0x0011)")
        print("  2: Heater Power Control (0x0012)")
        print("  3: Solenoid Valve Control (0x0013)")
        print("  4: Piezoelectric Pump Control (0x0014)")
        print("  5: Photo Power Control (0x0015)")
        print("  6: Laser Power Control (0x0016)")

        print("\n[PWM Control]")
        print("  9: PWM Heater Control (0x0090) - Freq + Duty + On/Off")
        
        print("\n[File Management]")
        print("  F: File Management (0x0080-0x0082)")
        
        print("\n[Quick Actions]")
        print("  A: Turn ALL devices ON")
        print("  D: Turn ALL devices OFF")
        
        print("\n[Other]")
        print("  C: Custom payload (manual hex input)")
        print("  B: Back to main menu")
        
        choice = input("\nSelect option: ").strip().upper()
        
        if choice == 'B':
            return
        
        elif choice == '0':
            print("\n--- Reading System Status (uptime + epoch) ---")
            payload = create_bee_payload(0x0000, b'\x00')
            inbuf = send_request(7, payload)
            
            if not inbuf:
                print("[ERROR] No response received.\n")
                continue

            data = bytes(inbuf[:9])  
            if len(data) < 9:
                print(f"[ERROR] Invalid data length: {len(data)} bytes (expected 9)\n")
                continue

            flag = data[0]
            uptime = int.from_bytes(data[1:5], "little")
            epoch = int.from_bytes(data[5:9], "little")

            print(f"\n[STATUS] Flag: {flag}")
            print(f"[STATUS] Uptime : {uptime} s ({uptime/3600:.2f} h)")
            print(f"[STATUS] Epoch  : {epoch}")
            print(f"[STATUS] Time   : {datetime.fromtimestamp(epoch).strftime('%Y-%m-%d %H:%M:%S')}\n")

            if flag != 0:
                print("[WARNING] System reported non-zero status flag!\n")
        
        elif choice in ['1', '2', '3', '4', '5', '6']:
            reg_map = {
                '1': (0x0011, "TEC"),
                '2': (0x0012, "Heater"),
                '3': (0x0013, "Solenoid Valve"),
                '4': (0x0014, "Piezo Pump"),
                '5': (0x0015, "Photo"),
                '6': (0x0016, "Laser")
            }
            
            reg_addr, device_name = reg_map[choice]
            
            print(f"\n--- {device_name} Control ---")
            action = input("Turn ON (1) or OFF (0)? ").strip()
            
            if action in ['0', '1']:
                data = int(action)
                payload = create_bee_payload(reg_addr, bytes([data]))
                print(f"\n[ACTION] {'Turning ON' if data else 'Turning OFF'} {device_name}...")
                inbuf = send_request(7, payload)
                if inbuf:
                    reply_str = inbuf.decode(errors="ignore").strip("\x00")
                    print(f"[REPLY] {reply_str}\n")
            else:
                print("[ERROR] Invalid input. Use 0 or 1.")
        elif choice == '9':
            pwm_heater_menu()

        elif choice == 'F':
            file_management_menu()
        
        elif choice == 'A':
            print("\n--- Turning ALL Devices ON ---")
            for reg_addr in [0x0011, 0x0012, 0x0013, 0x0014, 0x0015, 0x0016]:
                device_name = BEE_REGISTERS[reg_addr]["name"]
                payload = create_bee_payload(reg_addr, bytes([1]))
                print(f"\n[{device_name}]")
                inbuf = send_request(7, payload)
                if inbuf:
                    reply_str = inbuf.decode(errors="ignore").strip("\x00")
                    print(f"[REPLY] {reply_str}")
                time.sleep(0.2)
        
        elif choice == 'D':
            print("\n--- Turning ALL Devices OFF ---")
            for reg_addr in [0x0011, 0x0012, 0x0013, 0x0014, 0x0015, 0x0016]:
                device_name = BEE_REGISTERS[reg_addr]["name"]
                payload = create_bee_payload(reg_addr, bytes([0]))
                print(f"\n[{device_name}]")
                inbuf = send_request(7, payload)
                if inbuf:
                    reply_str = inbuf.decode(errors="ignore").strip("\x00")
                    print(f"[REPLY] {reply_str}")
                time.sleep(0.2)
        
        elif choice == 'C':
            print("\n--- Custom Payload ---")
            print("Format: AABBCC (hex bytes)")
            print("  AA BB = Register address (big-endian)")
            print("  CC... = Data values")
            print("Example: 001101 = Register 0x0011, Data 0x01 (TEC ON)")
            
            hex_input = input("\nEnter hex payload: ").strip().replace(" ", "")
            
            try:
                if len(hex_input) < 4:
                    print("[ERROR] Payload too short. Need at least 4 hex digits (2 bytes).")
                    continue
                
                payload = bytes.fromhex(hex_input)
                print(f"\n[PAYLOAD] Sending {len(payload)} bytes: {payload.hex().upper()}")
                inbuf = send_request(7, payload)
                if inbuf:
                    reply_str = inbuf.decode(errors="ignore").strip("\x00")
                    print(f"[REPLY] {reply_str}\n")
                
            except ValueError:
                print("[ERROR] Invalid hex input.")
        
        else:
            print("[ERROR] Invalid choice.")


def main():
    print("="*50)
    print("  OBC Interactive Menu - CSP Commander")
    print("="*50)
    print(f"\nOBC Node: {OBC_ADDRESS}")
    print(f"Target Node (EXP): {EXP_ADDRESS}")
    print(f"Interface: {CAN_INTERFACE}\n")

    print("[INIT] Initializing CSP...")
    libcsp.init(OBC_ADDRESS, "OBC", "Ground", "1.0", 10, 300)
    libcsp.can_socketcan_init(CAN_INTERFACE)
    libcsp.rtable_load("0/0 CAN")
    libcsp.route_start_task()
    time.sleep(0.2)
    print("[INIT] CSP initialized successfully!\n")

    while True:
        print("\n" + "="*50)
        print("  Main Menu")
        print("="*50)
        print("\n[Standard CSP Ports]")
        print("  0: CSP_CMD - Command")
        print("  1: CSP_PING - Ping test")
        print("  2: CSP_PS - Process info")
        print("  3: CSP_MEM_FREE - Memory info")
        print("  4: CSP_REBOOT - Reboot command")
        print("  5: CSP_BUF_FREE - Buffer info")
        print("  6: CSP_UPTIME - System uptime")
        
        print("\n[BEE Project]")
        print("  7: BEE_PARAMS - Device Control & File Management")
        
        print("\n[System]")
        print("  Q: Quit")

        choice = input("\nSelect option: ").strip().upper()
        
        if choice == 'Q':
            print("\n[EXIT] Goodbye!")
            break

        if choice == '7':
            bee_params_menu()
            continue

        if not choice.isdigit() or int(choice) not in PORTS:
            print("[ERROR] Invalid choice, try again.")
            continue

        port = int(choice)

        print(f"\n[INFO] Sending request to port {port} ({PORTS[port]})")
        inbuf = send_request(port)
        if inbuf:
            reply_str = inbuf.decode(errors="ignore").strip("\x00")
            print(f"[REPLY] {reply_str}\n")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n[EXIT] Interrupted by user. Goodbye!")
        sys.exit(0)
    except Exception as e:
        print(f"\n[FATAL ERROR] {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
