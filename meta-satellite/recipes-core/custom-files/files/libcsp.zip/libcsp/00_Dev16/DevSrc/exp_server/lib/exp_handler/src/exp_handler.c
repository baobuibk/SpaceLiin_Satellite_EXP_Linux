#include "exp_handler.h"

void exp_handler_init(void)
{
    // Initialization code for the experiment handler can be added here
}